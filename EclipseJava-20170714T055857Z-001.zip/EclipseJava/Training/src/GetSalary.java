import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class GetSalary {

public static void main(String args[]){
		
		Connection conn = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test1","root","root");
			String sql = "Select * from employee order by salary desc limit 5";
			PreparedStatement stmt = conn.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getInt("EmpNo")+" | "+rs.getString("Name")+" | "+rs.getInt("Age")+" | "+rs.getDouble("Salary"));
			}
			 if(!conn.isClosed())
				System.out.println("Succesfully connected");
		}catch(Exception e){
					System.err.println("Exception "+e.getMessage());
		}
	
	}
	
}
