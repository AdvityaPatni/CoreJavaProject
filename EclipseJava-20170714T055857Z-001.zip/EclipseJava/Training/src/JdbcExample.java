import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class JdbcExample{

		public static void main(String args[]){
	
		Connection conn = null;
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test1","root","root");
			String sql = "Insert into employee values(112,'Ashwin',25,25000.00)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			int rows = stmt.executeUpdate();
			System.out.println(rows);
			 if(!conn.isClosed())
				System.out.println("Succesfully connected");
		}catch(Exception e){
					System.err.println("Exception "+e.getMessage());
		}finally{
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException e){}
		}
		
	
	}

}