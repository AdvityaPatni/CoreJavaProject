
public class Lambda {

	final static String salutation = "Hello! ";
	
	public static void main(String[] args) {
		
		GreetinService greetService1 = message ->
		System.out.println(salutation + message);
		greetService1.sayMessage("Mahesh");
	}
	
	interface GreetinService{
		void sayMessage(String message);
	}

}
