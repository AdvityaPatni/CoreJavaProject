import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class LoanDetails {

	public static void main(String[] args) {
		
		Connection conn = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank_management","root","root");
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter bank Id:-");
			int id = sc.nextInt();
			System.out.println("Enter Loan Type:-");
			String type = sc.next();
			System.out.println(type);
			PreparedStatement stmt = conn.prepareStatement("Select L_ROI from loan where  L_BID=? and L_Type=?");
		
			stmt.setInt(1, id);
			stmt.setString(2, type);
		//	stmt.setString(3, "loan");
			ResultSet rs = stmt.executeQuery();
			rs.next();
			System.out.println(rs.getDouble(1));
			
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
