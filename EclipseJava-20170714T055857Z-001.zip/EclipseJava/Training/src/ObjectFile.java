import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;

public class ObjectFile {

	public ObjectFile() {
		//Date  d = new Date(); 
		EmployeeMain d = new EmployeeMain();
		EmployeeAdd ad = new EmployeeAdd();
		try {
				
				String s1= "Hello";
				FileOutputStream f = new FileOutputStream("date.ser");
				ObjectOutputStream s = new ObjectOutputStream(f);
				d.addEmployee();
				ArrayList<EmployeeVo> al = new ArrayList<EmployeeVo>();
				al = ad.getEmployeeList();
				
				s.writeObject(al);
				s.writeObject(s1);
				s.close();
				
				FileInputStream k = new FileInputStream("date.ser");
				ObjectInputStream l = new ObjectInputStream(k);
				
				al = (ArrayList<EmployeeVo>) l.readObject();
				s1 = (String) l.readObject();
				for(EmployeeVo t:al) {
					System.out.println(al+"  "+s1);
				}
				l.close();
				
		}catch(IOException | ClassNotFoundException e){
			System.out.println(e.getMessage());
		}
	}
	
	public static void main(String args[]) {
	
		new ObjectFile();
		System.out.println("Done");
		
	}
}
