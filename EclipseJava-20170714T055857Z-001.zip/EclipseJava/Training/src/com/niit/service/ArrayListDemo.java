package com.niit.service;

import java.util.ArrayList;

public class ArrayListDemo {

	public ArrayList<Integer> getMyList(){
		
		ArrayList<Integer> al = new ArrayList<Integer>();
		
		for(int i=0 ; i<5 ;i++) {
			al.add(i);
		}
		
		return al;
	}
	
}
