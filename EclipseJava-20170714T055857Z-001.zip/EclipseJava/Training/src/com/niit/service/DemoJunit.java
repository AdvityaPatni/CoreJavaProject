package com.niit.service;

public class DemoJunit {

	public String display(int num) {
		
		if(num>100) {
				System.out.println("more than 100");
				return ("more than 100");
				}
		else if(num>50) {
				System.out.println("Between 50 and 100");
				return("Between 50 and 100");
				}
		else if(num==20) {
			System.out.println(20);
			return "20";
			}
		else if(num==10) {
			System.out.println(10);
			return "10";
			}
		else
			return null;
		
	}
	
//	public static void main(String args[]) {
//		
//		}
	}

