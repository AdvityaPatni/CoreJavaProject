package com.niit.service;

public class MyClass {

	public int multiply(int x,int y) {
		if(x>999) {
			throw new IllegalArgumentException("X should be less than 1000");
		}
		return x*y;
	}
	
	public int add(int x,int y) {
		return x+y;
	}
	
	public int subtract(int x,int y) {
		return x-y;
	}
	
	public static void main(String args[]) {
		
		MyClass obj = new MyClass();
		System.out.println(obj.multiply(10, 20));
		
		System.out.println(obj.add(10, 20));
		
		System.out.println(obj.subtract(20, 10));
		
	}
	
}
