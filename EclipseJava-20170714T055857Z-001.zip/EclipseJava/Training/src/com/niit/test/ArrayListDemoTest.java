package com.niit.test;
import com.niit.service.*;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class ArrayListDemoTest {

	@Test
	public void test() {
		
		ArrayListDemo obj = new ArrayListDemo();
			
		assertEquals(5,obj.getMyList().size());
	}

}
