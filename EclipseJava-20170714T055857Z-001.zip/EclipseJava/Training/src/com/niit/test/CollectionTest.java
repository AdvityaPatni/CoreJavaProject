package com.niit.test;

import java.util.HashMap;
import java.util.Map;


import org.junit.Test;


//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CollectionTest {

	public static void main(String args[]) {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
	
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("j", "java");
		map.put("c", "c++");
		map.put("p", "Python");
		map.put("n", "nodejs");
		map.put("r", "ruby");
		
		 for(Map.Entry m:map.entrySet()){  
			   System.out.println(m.getKey()+" "+m.getValue());  
			  }  
		
		map.remove("p");
		 System.out.println();
		 for(Map.Entry m:map.entrySet()){
	
			   System.out.println(m.getKey()+" "+m.getValue());  
			 
			 
	}
		 
	}

}
