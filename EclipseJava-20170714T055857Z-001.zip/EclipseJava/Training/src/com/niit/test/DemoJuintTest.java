package com.niit.test;
import com.niit.service.*;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Before;
import org.junit.Test;

public class DemoJuintTest {

	//private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	
//	@Before
//	public void set() {
//		System.setOut(new PrintStream(outContent));
//	}
	
	@Test
	public void displaytest() {
		
		DemoJunit test = new DemoJunit();
	
		assertEquals("more than 100",test.display(101));
		//assertEquals("more than 100 ",outContent.toString());
		assertEquals("Between 50 and 100",test.display(75));
		
		assertEquals("20",test.display(20));
		assertEquals("10",test.display(10));
		
		assertEquals(null,test.display(15));
		
		
	}

}
