package com.niit.test;
import com.niit.service.*;
import static org.junit.Assert.*;

import org.junit.Test;

public class MessageUtilTest {

	String message = "Robert";	
	   MessageUtil messageUtil = new MessageUtil(message);
	   
	   @Test
	   public void testPrintMessage() {	
	      System.out.println("Inside testPrintMessage()");    
	      assertEquals(message, messageUtil.printMessage());    
	   }
}
