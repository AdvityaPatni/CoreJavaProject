package com.niit.test;

import com.niit.service.*;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class TestMyClass {

	@Test
	public void testMultiply() {
		
		MyClass obj = new MyClass();
		assertEquals(40, obj.multiply(10, 4));
	}
	
	@Test()
	public void testAdd() {
		MyClass obj = new MyClass();
		assertEquals(10,obj.add(5, 5));
	}

	@Test(expected = IllegalArgumentException.class)
	public void testMul() {
		MyClass obj = new MyClass();
		obj.multiply(1001, 5);
	}
}
